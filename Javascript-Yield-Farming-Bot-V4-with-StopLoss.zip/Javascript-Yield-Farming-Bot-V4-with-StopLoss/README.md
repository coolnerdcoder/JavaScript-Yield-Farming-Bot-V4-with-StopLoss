DEX Javascript-Yield-Farming-Bot-V4-with-StopLoss 
feel free to fork and improve or whatever. 
if you fork and modify please give credit
This is a tutorial to help run the Javascript Yield Farming Bot V4 with StopLoss (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the Javascript-Yield-Farming-Bot-V4-with-StopLoss.zip anywhere you like that easy for you to find.

Part 2. Editing the settings.

Open the bots main folder and find "config.js" file and open it with a text-editor:

1.Set your public address and private key or your wallet seed if you have a wallet that does not give you the private key

2.Set the Network  1 = ETH , 2 = BNB , 3 = Polygon

3.Save config.js

4.Open index.html in any web-browser


